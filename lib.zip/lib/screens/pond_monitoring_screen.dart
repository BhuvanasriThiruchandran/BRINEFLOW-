import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/ui.dart';

class PondMonitoringScreen extends StatefulWidget {
  const PondMonitoringScreen({super.key});

  @override
  State<PondMonitoringScreen> createState() => _PondMonitoringScreenState();
}

class _PondMonitoringScreenState extends State<PondMonitoringScreen> {
  int selected = 0;

  final ponds = const [
    _Pond(
      name: 'Reservoir',
      stage: 'Intake & storage',
      level: '82%',
      salinity: '0 ppt',
      temp: '30°C',
      humidity: '65%',
      status: 'Stable',
      color: AppTheme.ocean,
    ),
    _Pond(
      name: 'Evaporation',
      stage: 'Concentration',
      level: '62%',
      salinity: '25.8 ppt',
      temp: '35°C',
      humidity: '68%',
      status: 'Monitor',
      color: AppTheme.warning,
    ),
    _Pond(
      name: 'Crystallizer',
      stage: 'Crystal formation',
      level: '41%',
      salinity: '31.2 ppt',
      temp: '36°C',
      humidity: '64%',
      status: 'Ready',
      color: AppTheme.success,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final pond = ponds[selected];
    return AppPage(
      title: 'Pond monitoring',
      subtitle: '3 ponds • sensor telemetry',
      actions: [
        IconButton(
          tooltip: 'Refresh',
          onPressed: () => setState(() {}),
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          SizedBox(
            height: 42,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: ponds.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) => ChoiceChip(
                label: Text(ponds[i].name),
                selected: selected == i,
                onSelected: (_) => setState(() => selected = i),
              ),
            ),
          ),
          const SizedBox(height: 16),
          GlassCard(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        pond.color,
                        pond.color.withValues(alpha: .72),
                      ],
                    ),
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(22),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 56,
                        height: 56,
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: .16),
                          borderRadius: BorderRadius.circular(17),
                        ),
                        child: const Icon(
                          Icons.water_drop_rounded,
                          color: Colors.white,
                          size: 29,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${pond.name} Pond',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            Text(
                              pond.stage,
                              style: const TextStyle(color: Colors.white70),
                            ),
                          ],
                        ),
                      ),
                      StatusPill(text: pond.status.toUpperCase(), color: Colors.white),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    children: [
                      _Reading(
                        icon: Icons.water_drop_outlined,
                        label: 'Water level',
                        value: pond.level,
                        color: AppTheme.ocean,
                      ),
                      _Reading(
                        icon: Icons.science_outlined,
                        label: 'Salinity',
                        value: pond.salinity,
                        color: Colors.deepPurple,
                      ),
                      _Reading(
                        icon: Icons.thermostat_outlined,
                        label: 'Temperature',
                        value: pond.temp,
                        color: AppTheme.warning,
                      ),
                      _Reading(
                        icon: Icons.air_outlined,
                        label: 'Humidity',
                        value: pond.humidity,
                        color: AppTheme.cyan,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          const SectionTitle(title: 'Operational interpretation'),
          const SizedBox(height: 10),
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  selected == 2
                      ? 'Brine is approaching the crystallization target.'
                      : selected == 1
                          ? 'Continue evaporation while watching temperature and salinity.'
                          : 'Reservoir level is suitable for normal transfer scheduling.',
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 12),
                ProgressMetric(
                  title: 'Brine readiness',
                  value: selected == 2 ? .86 : selected == 1 ? .64 : .48,
                  valueLabel: selected == 2 ? '86 / 100' : selected == 1 ? '64 / 100' : '48 / 100',
                  color: pond.color,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Reading extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _Reading({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, size: 19, color: color),
          const SizedBox(width: 12),
          Expanded(child: Text(label)),
          Text(
            value,
            style: const TextStyle(fontWeight: FontWeight.w900),
          ),
        ],
      ),
    );
  }
}

class _Pond {
  final String name, stage, level, salinity, temp, humidity, status;
  final Color color;

  const _Pond({
    required this.name,
    required this.stage,
    required this.level,
    required this.salinity,
    required this.temp,
    required this.humidity,
    required this.status,
    required this.color,
  });
}
