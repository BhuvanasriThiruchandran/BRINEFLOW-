import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/ui.dart';

class ProfitPredictionScreen extends StatelessWidget {
  const ProfitPredictionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'Profit forecast',
      subtitle: 'Projected economics for current cycle',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF312E81), Color(0xFF7C3AED)],
              ),
              borderRadius: BorderRadius.circular(26),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Estimated profit',
                  style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 6),
                Text(
                  '₹3.2M',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 38,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                SizedBox(height: 6),
                Text(
                  'Projected margin • 67%',
                  style: TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          const MetricTile(
            label: 'Revenue estimate',
            value: '₹4.8M',
            helper: 'Based on predicted yield',
            icon: Icons.trending_up_rounded,
            color: AppTheme.success,
          ),
          const SizedBox(height: 10),
          const MetricTile(
            label: 'Operational cost',
            value: '₹1.6M',
            helper: 'Current cycle estimate',
            icon: Icons.account_balance_wallet_outlined,
            color: AppTheme.warning,
          ),
          const SizedBox(height: 18),
          const SectionTitle(title: 'Financial breakdown'),
          const SizedBox(height: 10),
          const GlassCard(
            child: Column(
              children: [
                ProgressMetric(
                  title: 'Projected revenue',
                  value: .80,
                  valueLabel: '₹4.8M',
                  color: AppTheme.success,
                ),
                SizedBox(height: 20),
                ProgressMetric(
                  title: 'Projected cost',
                  value: .27,
                  valueLabel: '₹1.6M',
                  color: AppTheme.warning,
                ),
                SizedBox(height: 20),
                ProgressMetric(
                  title: 'Net profit',
                  value: .67,
                  valueLabel: '67%',
                  color: Colors.deepPurple,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
