import 'package:flutter/material.dart';
import '../providers/theme_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/ui.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool notifications = true;
  bool autoSync = true;

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'Settings',
      subtitle: 'Preferences & system controls',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          const SectionTitle(title: 'Preferences'),
          const SizedBox(height: 10),
          _Setting(
            icon: Icons.notifications_none_rounded,
            title: 'Notifications',
            subtitle: 'Receive operational alerts',
            color: AppTheme.ocean,
            trailing: Switch(
              value: notifications,
              onChanged: (v) => setState(() => notifications = v),
            ),
          ),
          _Setting(
            icon: Icons.sync_rounded,
            title: 'Automatic sync',
            subtitle: 'Keep sensor data synchronized',
            color: AppTheme.success,
            trailing: Switch(
              value: autoSync,
              onChanged: (v) => setState(() => autoSync = v),
            ),
          ),
          _Setting(
            icon: Icons.dark_mode_outlined,
            title: 'Dark mode',
            subtitle: 'Use a darker interface',
            color: Colors.deepPurple,
            trailing: AnimatedBuilder(
              animation: appThemeProvider,
              builder: (_, __) => Switch(
                value: appThemeProvider.isDarkMode,
                onChanged: (_) => appThemeProvider.toggleTheme(),
              ),
            ),
          ),
          const SizedBox(height: 18),
          const SectionTitle(title: 'System'),
          const SizedBox(height: 10),
          _Setting(
            icon: Icons.info_outline_rounded,
            title: 'About BrineFlow',
            subtitle: 'Version 2.0 • Intelligent Saltpan Management',
            color: AppTheme.cyan,
            trailing: const Icon(Icons.chevron_right_rounded),
          ),
          _Setting(
            icon: Icons.cloud_done_outlined,
            title: 'Backend connection',
            subtitle: 'Supabase / API connection status',
            color: AppTheme.success,
            trailing: const StatusPill(text: 'CONNECTED', color: AppTheme.success),
          ),
        ],
      ),
    );
  }
}

class _Setting extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final Color color;
  final Widget trailing;

  const _Setting({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GlassCard(
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: color.withValues(alpha: .10),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 11,
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
            trailing,
          ],
        ),
      ),
    );
  }
}
