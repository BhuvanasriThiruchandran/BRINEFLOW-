import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/dashboard_header.dart';
import '../widgets/sensor_card.dart';
import '../widgets/ui.dart';
import 'alert_screen.dart';
import 'pond_monitoring_screen.dart';
import 'weather_screen.dart';
import 'yield_prediction_screen.dart';
import 'profit_prediction_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  void open(BuildContext context, Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'Operations overview',
      subtitle: 'Thursday, 27 August 2026',
      actions: [
        IconButton(
          tooltip: 'Notifications',
          onPressed: () => open(context, const AlertScreen()),
          icon: const Icon(Icons.notifications_none_rounded),
        ),
      ],
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            DashboardHero(
              onAlerts: () => open(context, const AlertScreen()),
            ),
            const SizedBox(height: 22),
            const SectionTitle(title: 'Today at a glance'),
            const SizedBox(height: 10),
            LayoutBuilder(
              builder: (context, c) {
                final columns = c.maxWidth > 760 ? 4 : 2;
                final width = (c.maxWidth - (columns - 1) * 12) / columns;
                return Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    SizedBox(
                      width: width,
                      child: const MetricTile(
                        label: 'Expected yield',
                        value: '4.8 t',
                        helper: '+8.4% vs cycle avg.',
                        icon: Icons.inventory_2_outlined,
                        color: AppTheme.success,
                      ),
                    ),
                    SizedBox(
                      width: width,
                      child: const MetricTile(
                        label: 'BRS score',
                        value: '86 / 100',
                        helper: 'Ready for transfer',
                        icon: Icons.analytics_outlined,
                        color: AppTheme.ocean,
                      ),
                    ),
                    SizedBox(
                      width: width,
                      child: const MetricTile(
                        label: 'Rain probability',
                        value: '18%',
                        helper: 'Low risk today',
                        icon: Icons.umbrella_outlined,
                        color: AppTheme.warning,
                      ),
                    ),
                    SizedBox(
                      width: width,
                      child: const MetricTile(
                        label: 'Est. profit',
                        value: '₹3.2M',
                        helper: 'Projected cycle',
                        icon: Icons.currency_rupee_rounded,
                        color: Colors.deepPurple,
                      ),
                    ),
                  ],
                );
              },
            ),
            const SizedBox(height: 22),
            const SectionTitle(title: 'Live pond status'),
            const SizedBox(height: 10),
            LayoutBuilder(
              builder: (context, c) {
                final wide = c.maxWidth > 760;
                final children = [
                  const SensorCard(
                    title: 'Reservoir Pond',
                    value: '82%',
                    subtitle: 'Water level • stable',
                    icon: Icons.water_drop_outlined,
                    color: AppTheme.ocean,
                    progress: .82,
                  ),
                  const SensorCard(
                    title: 'Evaporation Pond',
                    value: '35°C',
                    subtitle: 'Temperature • elevated',
                    icon: Icons.thermostat_outlined,
                    color: AppTheme.warning,
                    progress: .74,
                  ),
                  const SensorCard(
                    title: 'Crystallizer Pond',
                    value: '31 ppt',
                    subtitle: 'Salinity • target range',
                    icon: Icons.science_outlined,
                    color: AppTheme.success,
                    progress: .88,
                  ),
                ];
                if (wide) {
                  return Row(
                    children: children
                        .map(
                          (w) => Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(right: 12),
                              child: w,
                            ),
                          ),
                        )
                        .toList(),
                  );
                }
                return Column(
                  children: children
                      .map(
                        (w) => Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: w,
                        ),
                      )
                      .toList(),
                );
              },
            ),
            const SizedBox(height: 10),
            GlassCard(
              child: Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: AppTheme.success.withValues(alpha: .10),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Icon(
                      Icons.check_circle_outline_rounded,
                      color: AppTheme.success,
                    ),
                  ),
                  const SizedBox(width: 13),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'System health is good',
                          style: TextStyle(fontWeight: FontWeight.w800),
                        ),
                        SizedBox(height: 3),
                        Text(
                          'All configured sensors are transmitting normally.',
                          style: TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  TextButton(
                    onPressed: null,
                    child: Text('Live'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 22),
            const SectionTitle(title: 'Quick actions'),
            const SizedBox(height: 10),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                _Action(
                  icon: Icons.water_drop_outlined,
                  label: 'Inspect ponds',
                  onTap: () => open(context, const PondMonitoringScreen()),
                ),
                _Action(
                  icon: Icons.cloud_outlined,
                  label: 'Weather',
                  onTap: () => open(context, const WeatherScreen()),
                ),
                _Action(
                  icon: Icons.insights_outlined,
                  label: 'Yield forecast',
                  onTap: () => open(context, const YieldPredictionScreen()),
                ),
                _Action(
                  icon: Icons.currency_rupee_rounded,
                  label: 'Profit',
                  onTap: () => open(context, const ProfitPredictionScreen()),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _Action extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _Action({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return FilledButton.tonalIcon(
      onPressed: onTap,
      icon: Icon(icon),
      label: Text(label),
      style: FilledButton.styleFrom(
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      ),
    );
  }
}
