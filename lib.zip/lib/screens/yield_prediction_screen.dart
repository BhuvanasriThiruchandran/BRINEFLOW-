import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/ui.dart';

class YieldPredictionScreen extends StatelessWidget {
  const YieldPredictionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'Yield prediction',
      subtitle: 'Random Forest production forecast',
      actions: [
        IconButton(
          onPressed: () {},
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppTheme.success, Color(0xFF22C55E)],
              ),
              borderRadius: BorderRadius.circular(26),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Predicted salt yield',
                  style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 6),
                Text(
                  '4.8 tons',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 38,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                SizedBox(height: 6),
                Text(
                  'Forecast confidence • 92%',
                  style: TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(
                child: MetricTile(
                  label: 'Harvest',
                  value: '3 days',
                  helper: 'Expected window',
                  icon: Icons.event_available_outlined,
                  color: AppTheme.ocean,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: MetricTile(
                  label: 'Efficiency',
                  value: '91%',
                  helper: 'Cycle estimate',
                  icon: Icons.speed_rounded,
                  color: AppTheme.success,
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          const SectionTitle(title: 'Prediction trend'),
          const SizedBox(height: 10),
          const GlassCard(
            child: SizedBox(
              height: 210,
              child: _YieldChart(),
            ),
          ),
          const SizedBox(height: 18),
          const SectionTitle(title: 'Model inputs'),
          const SizedBox(height: 10),
          const GlassCard(
            child: Column(
              children: [
                ProgressMetric(
                  title: 'Salinity contribution',
                  value: .88,
                  valueLabel: '31.2 ppt',
                  color: Colors.deepPurple,
                ),
                SizedBox(height: 18),
                ProgressMetric(
                  title: 'Temperature contribution',
                  value: .76,
                  valueLabel: '36°C',
                  color: AppTheme.warning,
                ),
                SizedBox(height: 18),
                ProgressMetric(
                  title: 'Water level contribution',
                  value: .63,
                  valueLabel: '41%',
                  color: AppTheme.ocean,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _YieldChart extends StatelessWidget {
  const _YieldChart();

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _ChartPainter(
        values: const [0.42, 0.50, 0.48, 0.63, 0.70, 0.76, 0.86],
      ),
      child: const SizedBox.expand(),
    );
  }
}

class _ChartPainter extends CustomPainter {
  final List<double> values;
  _ChartPainter({required this.values});

  @override
  void paint(Canvas canvas, Size size) {
    final line = Paint()
      ..color = AppTheme.success
      ..strokeWidth = 4
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final fill = Paint()
      ..color = AppTheme.success.withValues(alpha: .10)
      ..style = PaintingStyle.fill;
    final grid = Paint()
      ..color = Colors.grey.withValues(alpha: .18)
      ..strokeWidth = 1;

    for (int i = 1; i < 4; i++) {
      final y = size.height * i / 4;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    final path = Path();
    final area = Path();
    for (int i = 0; i < values.length; i++) {
      final x = size.width * i / (values.length - 1);
      final y = size.height * (1 - values[i]);
      if (i == 0) {
        path.moveTo(x, y);
        area.moveTo(x, size.height);
        area.lineTo(x, y);
      } else {
        path.lineTo(x, y);
        area.lineTo(x, y);
      }
    }
    area.lineTo(size.width, size.height);
    area.close();

    canvas.drawPath(area, fill);
    canvas.drawPath(path, line);

    final dot = Paint()..color = AppTheme.success;
    for (int i = 0; i < values.length; i++) {
      final x = size.width * i / (values.length - 1);
      final y = size.height * (1 - values[i]);
      canvas.drawCircle(Offset(x, y), 5, dot);
    }
  }

  @override
  bool shouldRepaint(covariant _ChartPainter oldDelegate) => oldDelegate.values != values;
}
