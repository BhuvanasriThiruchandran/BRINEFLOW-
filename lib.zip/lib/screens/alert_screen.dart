import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/ui.dart';

class AlertScreen extends StatefulWidget {
  const AlertScreen({super.key});

  @override
  State<AlertScreen> createState() => _AlertScreenState();
}

class _AlertScreenState extends State<AlertScreen> {
  int filter = 0;

  final alerts = const [
    _Alert(
      title: 'High salinity',
      message: 'Crystallizer pond reached 33 ppt. Review brine readiness.',
      time: '8 min ago',
      severity: 'Attention',
      color: AppTheme.warning,
      icon: Icons.science_outlined,
    ),
    _Alert(
      title: 'Sensor offline',
      message: 'Reservoir telemetry has not reported a recent reading.',
      time: '26 min ago',
      severity: 'Critical',
      color: AppTheme.danger,
      icon: Icons.sensors_off_outlined,
    ),
    _Alert(
      title: 'Maintenance reminder',
      message: 'Inspect pumps before the next transfer cycle.',
      time: '2 hr ago',
      severity: 'Info',
      color: AppTheme.ocean,
      icon: Icons.build_outlined,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'Alerts',
      subtitle: 'Operational notifications',
      actions: [
        TextButton(
          onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('All visible alerts marked as read.')),
          ),
          child: const Text('Mark all read'),
        ),
      ],
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          SegmentedButton<int>(
            segments: const [
              ButtonSegment(value: 0, label: Text('All')),
              ButtonSegment(value: 1, label: Text('Critical')),
              ButtonSegment(value: 2, label: Text('Attention')),
            ],
            selected: {filter},
            onSelectionChanged: (s) => setState(() => filter = s.first),
          ),
          const SizedBox(height: 16),
          ...alerts
              .where(
                (a) =>
                    filter == 0 ||
                    (filter == 1 && a.severity == 'Critical') ||
                    (filter == 2 && a.severity == 'Attention'),
              )
              .map(
                (a) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: GlassCard(
                    onTap: () => showModalBottomSheet(
                      context: context,
                      showDragHandle: true,
                      builder: (_) => Padding(
                        padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              a.title,
                              style: const TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(a.message),
                            const SizedBox(height: 14),
                            StatusPill(text: a.severity.toUpperCase(), color: a.color),
                          ],
                        ),
                      ),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 46,
                          height: 46,
                          decoration: BoxDecoration(
                            color: a.color.withValues(alpha: .10),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Icon(a.icon, color: a.color),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      a.title,
                                      style: const TextStyle(fontWeight: FontWeight.w900),
                                    ),
                                  ),
                                  Text(
                                    a.time,
                                    style: TextStyle(
                                      fontSize: 10,
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceVariant,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 6),
                              Text(
                                a.message,
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Theme.of(context)
                                      .colorScheme
                                      .onSurfaceVariant,
                                ),
                              ),
                              const SizedBox(height: 9),
                              StatusPill(text: a.severity.toUpperCase(), color: a.color),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
        ],
      ),
    );
  }
}

class _Alert {
  final String title, message, time, severity;
  final Color color;
  final IconData icon;

  const _Alert({
    required this.title,
    required this.message,
    required this.time,
    required this.severity,
    required this.color,
    required this.icon,
  });
}
