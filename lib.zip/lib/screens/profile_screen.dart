import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/ui.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'Profile',
      subtitle: 'Account & operations role',
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          GlassCard(
            child: Column(
              children: [
                Container(
                  width: 86,
                  height: 86,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AppTheme.ocean, AppTheme.cyan],
                    ),
                    borderRadius: BorderRadius.circular(28),
                  ),
                  child: const Icon(
                    Icons.person_rounded,
                    color: Colors.white,
                    size: 44,
                  ),
                ),
                const SizedBox(height: 13),
                const Text(
                  'Saltpan Administrator',
                  style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 4),
                Text(
                  'Operations Manager',
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 13),
                const StatusPill(text: 'ACTIVE ACCOUNT', color: AppTheme.success),
              ],
            ),
          ),
          const SizedBox(height: 14),
          const _Info(label: 'Email', value: 'admin@brineflow.app', icon: Icons.mail_outline),
          const _Info(label: 'Assigned ponds', value: '3 active ponds', icon: Icons.water_drop_outlined),
          const _Info(label: 'Access level', value: 'Administrator', icon: Icons.admin_panel_settings_outlined),
        ],
      ),
    );
  }
}

class _Info extends StatelessWidget {
  final String label, value;
  final IconData icon;

  const _Info({
    required this.label,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GlassCard(
        child: Row(
          children: [
            Icon(icon, color: AppTheme.ocean),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.onSurfaceVariant)),
                  const SizedBox(height: 3),
                  Text(value, style: const TextStyle(fontWeight: FontWeight.w800)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded),
          ],
        ),
      ),
    );
  }
}
