import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/ui.dart';

class WeatherScreen extends StatelessWidget {
  const WeatherScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'Weather intelligence',
      subtitle: 'Operational weather outlook',
      actions: [
        IconButton(
          onPressed: () {},
          icon: const Icon(Icons.location_on_outlined),
          tooltip: 'Pond location',
        ),
      ],
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppTheme.ocean, AppTheme.cyan],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(26),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.wb_sunny_rounded, color: Colors.white, size: 32),
                    SizedBox(width: 12),
                    Text(
                      'Sunny',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10),
                Text(
                  '32°C  •  Light wind  •  Humidity 62%',
                  style: TextStyle(color: Colors.white70),
                ),
                SizedBox(height: 18),
                Row(
                  children: [
                    StatusPill(text: 'LOW RAIN RISK', color: Colors.white),
                    SizedBox(width: 9),
                    Text(
                      'Rain probability 18%',
                      style: TextStyle(color: Colors.white70, fontSize: 11),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          const SectionTitle(title: 'Conditions'),
          const SizedBox(height: 10),
          const MetricTile(
            label: 'Humidity',
            value: '62%',
            helper: 'Favourable for evaporation',
            icon: Icons.water_drop_outlined,
            color: AppTheme.ocean,
          ),
          const SizedBox(height: 10),
          const MetricTile(
            label: 'Wind speed',
            value: '12 km/h',
            helper: 'Gentle breeze',
            icon: Icons.air_rounded,
            color: Colors.indigo,
          ),
          const SizedBox(height: 10),
          const MetricTile(
            label: 'UV index',
            value: '7.2',
            helper: 'High solar exposure',
            icon: Icons.wb_sunny_outlined,
            color: AppTheme.warning,
          ),
          const SizedBox(height: 18),
          const SectionTitle(title: '5-day operational outlook'),
          const SizedBox(height: 10),
          GlassCard(
            child: Column(
              children: const [
                _Forecast(day: 'Thu', temp: '32°', rain: '18%', icon: Icons.wb_sunny_outlined),
                _Forecast(day: 'Fri', temp: '33°', rain: '12%', icon: Icons.wb_sunny_rounded),
                _Forecast(day: 'Sat', temp: '31°', rain: '34%', icon: Icons.cloud_outlined),
                _Forecast(day: 'Sun', temp: '30°', rain: '48%', icon: Icons.cloudy_snowing),
                _Forecast(day: 'Mon', temp: '32°', rain: '22%', icon: Icons.wb_sunny_outlined),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Forecast extends StatelessWidget {
  final String day, temp, rain;
  final IconData icon;

  const _Forecast({
    required this.day,
    required this.temp,
    required this.rain,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 9),
      child: Row(
        children: [
          SizedBox(width: 44, child: Text(day, style: const TextStyle(fontWeight: FontWeight.w800))),
          Icon(icon, size: 20, color: AppTheme.warning),
          const SizedBox(width: 12),
          Text(temp, style: const TextStyle(fontWeight: FontWeight.w800)),
          const Spacer(),
          Text(
            '$rain rain',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}
