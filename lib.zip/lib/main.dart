import 'package:flutter/material.dart';
import 'providers/theme_provider.dart';
import 'screens/splash_screen.dart';
import 'theme/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BrineFlowApp());
}

class BrineFlowApp extends StatefulWidget {
  const BrineFlowApp({super.key});

  @override
  State<BrineFlowApp> createState() => _BrineFlowAppState();
}

class _BrineFlowAppState extends State<BrineFlowApp> {
  final ThemeProvider _themeProvider = appThemeProvider;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _themeProvider,
      builder: (context, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'BrineFlow',
          theme: AppTheme.lightTheme,
          darkTheme: AppTheme.darkTheme,
          themeMode: _themeProvider.isDarkMode
              ? ThemeMode.dark
              : ThemeMode.light,
          home: const SplashScreen(),
        );
      },
    );
  }
}
